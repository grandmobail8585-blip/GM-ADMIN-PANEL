package com.gmadmin.panel

import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayParams(width: Int, height: Int) = WindowManager.LayoutParams(
        width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showBubble() {
        if (bubble != null) return
        val button = TextView(this).apply {
            text = "GM"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(190, 25, 45))
            elevation = 12f
            setOnClickListener { togglePanel() }
        }
        bubbleParams = overlayParams(dp(52), dp(52)).apply {
            x = dp(12); y = dp(180)
        }
        button.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0
            var startY = 0
            var touchX = 0f
            var touchY = 0f
            var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = bubbleParams.x; startY = bubbleParams.y
                        touchX = event.rawX; touchY = event.rawY; moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).toInt()
                        val dy = (event.rawY - touchY).toInt()
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                        bubbleParams.x = startX + dx
                        bubbleParams.y = startY + dy
                        wm.updateViewLayout(button, bubbleParams)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
        bubble = button
        wm.addView(button, bubbleParams)
    }

    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(27, 27, 33))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply {
            text = "GM ADMIN"
            textSize = 18f
            setTextColor(Color.WHITE)
        }
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { hidePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(44)))
        card.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val playerId = field("ID игрока (введите вручную)")
        val reason = field("Причина")
        val duration = field("Срок, например 60m / 1d")
        content.addView(label("Игрок"))
        content.addView(playerId)
        content.addView(label("Причина"))
        content.addView(reason)
        content.addView(label("Срок наказания"))
        content.addView(duration)

        val commands = listOf(
            "kick" to false, "ban" to true, "mute" to true, "warn" to false,
            "goto" to false, "gethere" to false, "getcar" to false
        )
        commands.forEach { (command, needsDuration) ->
            val btn = Button(this).apply {
                text = command.uppercase()
                setOnClickListener {
                    val id = playerId.text.toString().trim()
                    val why = reason.text.toString().trim()
                    val time = duration.text.toString().trim()
                    val cmd = when (command) {
                        "kick" -> "/kick $id ${why.ifBlank { "причина" }}"
                        "ban" -> "/ban $id ${time.ifBlank { "срок" }} ${why.ifBlank { "причина" }}"
                        "mute" -> "/mute $id ${time.ifBlank { "срок" }} ${why.ifBlank { "причина" }}"
                        "warn" -> "/warn $id ${why.ifBlank { "причина" }}"
                        "goto" -> "/goto $id"
                        "gethere" -> "/gethere $id"
                        "getcar" -> "/getcar $id"
                        else -> ""
                    }
                    copyCommand(cmd)
                }
            }
            content.addView(btn)
        }
        val note = TextView(this).apply {
            text = "Команда копируется в буфер обмена. Формат команд — примерный: проверь синтаксис в официальной документации проекта."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(4))
        }
        content.addView(note)
        scroll.addView(content)
        card.addView(scroll, LinearLayout.LayoutParams(-1, dp(420)))

        val params = overlayParams(dp(290), dp(500)).apply {
            x = dp(70); y = dp(90)
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        panel = card
        wm.addView(card, params)
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(Color.WHITE)
        textSize = 14f
        singleLine = true
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(6), 0, 0)
    }

    private fun copyCommand(value: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("GM command", value))
        Toast.makeText(this, "Команда скопирована: $value", Toast.LENGTH_LONG).show()
    }

    private fun hidePanel() {
        panel?.let { wm.removeView(it) }
        panel = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        hidePanel()
        bubble?.let { wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }
}

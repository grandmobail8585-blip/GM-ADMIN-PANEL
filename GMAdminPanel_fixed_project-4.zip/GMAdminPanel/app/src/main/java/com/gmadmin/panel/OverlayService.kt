package com.gmadmin.panel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color

data class Cmd(val level: Int, val name: String, val hint: String)

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val commands = listOf(
        Cmd(1,"/a","Текст"), Cmd(1,"/admins",""), Cmd(1,"/medias",""), Cmd(1,"/arep",""),
        Cmd(1,"/ans","ID игрока; текст"), Cmd(1,"/pm","ID игрока; текст"), Cmd(1,"/pos","X; Y; Z"),
        Cmd(1,"/setpass","Пароль"), Cmd(1,"/az",""), Cmd(1,"/gm",""), Cmd(1,"/sp","ID игрока"),
        Cmd(1,"/spoff",""), Cmd(1,"/hp","ID игрока; значение 0–100"), Cmd(1,"/alic","ID игрока"),
        Cmd(1,"/fixcar","ID игрока"), Cmd(1,"/getinfo","ID игрока"), Cmd(1,"/flip","ID игрока"), Cmd(1,"/clist",""),
        Cmd(2,"/spawn","ID игрока"), Cmd(2,"/freeze","ID игрока"), Cmd(2,"/tp",""), Cmd(2,"/slap","ID игрока"),
        Cmd(2,"/kick","ID игрока; причина"), Cmd(2,"/mute","ID игрока; время; причина"), Cmd(2,"/unmute","ID игрока"),
        Cmd(2,"/offmute","Nickname; время; причина"), Cmd(2,"/offunmute","Nickname"), Cmd(2,"/jail","ID игрока; время; причина"),
        Cmd(2,"/unjail","ID игрока"), Cmd(2,"/offjail","Nickname; время; причина"), Cmd(2,"/offunjail","Nickname"),
        Cmd(2,"/rmute","ID игрока; время; причина"), Cmd(2,"/runmute","ID игрока"), Cmd(2,"/offrmute","Nickname; время; причина"),
        Cmd(2,"/offrunmute","Nickname"), Cmd(2,"/weap","ID игрока"), Cmd(2,"/stats","ID игрока"), Cmd(2,"/connect",""),
        Cmd(2,"/mark",""), Cmd(2,"/gotomark",""), Cmd(2,"/checkpunish","uid/name; значение; дни"),
        Cmd(2,"/goto","ID игрока"), Cmd(2,"/gotocar","ID машины"), Cmd(2,"/getcar","ID машины"),
        Cmd(2,"/skills","ID игрока"), Cmd(2,"/pay","ID игрока; сумма"), Cmd(2,"/unfreeze","ID игрока"),
        Cmd(2,"/leaders",""), Cmd(2,"/heal","ID игрока"), Cmd(2,"/deadlist","ID игрока"),
        Cmd(3,"/ban","ID игрока; дни; причина"), Cmd(3,"/offwarn","Nickname; причина"), Cmd(3,"/offunwarn","Nickname"),
        Cmd(3,"/skick","ID игрока"), Cmd(3,"/veh_find","Критерии"), Cmd(3,"/warn","ID игрока; причина"),
        Cmd(3,"/unwarn","ID игрока"), Cmd(3,"/gethere","ID игрока"), Cmd(3,"/as","Текст"),
        Cmd(3,"/hpall","Значение"), Cmd(3,"/weapall",""), Cmd(3,"/arm","ID игрока; значение 0–100"),
        Cmd(3,"/uncuff","ID игрока"), Cmd(3,"/acceptgnews",""), Cmd(3,"/find",""),
        Cmd(3,"/f","Текст"), Cmd(3,"/r","Текст"), Cmd(3,"/d","Текст"), Cmd(3,"/spcar","ID транспорта"),
        Cmd(3,"/spcars","Критерии"), Cmd(3,"/untie","ID игрока"), Cmd(3,"/tempfrac","ID игрока"),
        Cmd(4,"/sban","ID игрока; время; причина"), Cmd(4,"/unban","Nickname"), Cmd(4,"/offban","Nickname; время; причина"),
        Cmd(4,"/house","ID дома"), Cmd(4,"/biz","ID бизнеса"), Cmd(4,"/okay","ID игрока"),
        Cmd(4,"/no","ID игрока; причина"), Cmd(4,"/setskin","ID игрока; ID скина"),
        Cmd(4,"/setfuel","ID транспорта; значение 0–150"), Cmd(4,"/getname","Номер аккаунта"),
        Cmd(4,"/history","Nickname"), Cmd(4,"/rgun","ID игрока"), Cmd(4,"/lip","IP адрес")
    )

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun params(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(-2, -2, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 180
        }
    }

    private fun showBubble() {
        bubble = TextView(this).apply {
            text = "GM"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
            setBackgroundColor(Color.rgb(45, 75, 130))
            setOnClickListener { if (panel == null) showPanel() else closePanel() }
        }
        wm.addView(bubble, params())
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(25, 28, 36))
        }
        val head = TextView(this).apply {
            text = "GM ADMIN  •  нажми GM, чтобы закрыть"
            textSize = 16f; setTextColor(Color.WHITE)
        }
        box.addView(head)
        val search = EditText(this).apply {
            hint = "Поиск команды"; setSingleLine(true)
        }
        box.addView(search)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        var selected = 1
        fun refresh() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase()
            commands.filter { it.level == selected && (q.isEmpty() || it.name.contains(q)) }.forEach { cmd ->
                val b = Button(this).apply {
                    text = cmd.name + if (cmd.hint.isNotEmpty()) "  ·  ${cmd.hint}" else ""
                    textSize = 12f
                    setOnClickListener { promptCommand(cmd) }
                }
                list.addView(b)
            }
        }
        (1..4).forEach { level ->
            tabs.addView(Button(this).apply {
                text = "Уровень $level"
                setOnClickListener { selected = level; refresh() }
            })
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        box.addView(tabs)
        box.addView(scroll, LinearLayout.LayoutParams(320, 620))
        panel = box
        val p = params().apply {
            width = 360; height = 760
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        wm.addView(box, p)
        refresh()
    }

    private fun promptCommand(cmd: Cmd) {
        val parts = cmd.hint.split(";").map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) { copy(cmd.name); return }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 8) }
        val inputs = parts.map { label ->
            EditText(this).apply { hint = label; setSingleLine(true); fields.addView(this) }
        }
        AlertDialogCompat.show(this, cmd.name, fields) {
            val args = inputs.map { it.text.toString().trim() }
            if (args.any { it.isEmpty() }) {
                Toast.makeText(this, "Заполни все поля", Toast.LENGTH_SHORT).show()
            } else copy(cmd.name + " " + args.joinToString(" "))
        }
    }

    private fun copy(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("GM command", text))
        Toast.makeText(this, "Скопировано: $text", Toast.LENGTH_LONG).show()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

object AlertDialogCompat {
    fun show(context: Context, title: String, view: View, onCopy: () -> Unit) {
        android.app.AlertDialog.Builder(context)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Копировать команду") { _, _ -> onCopy() }
            .show()
    }
}
